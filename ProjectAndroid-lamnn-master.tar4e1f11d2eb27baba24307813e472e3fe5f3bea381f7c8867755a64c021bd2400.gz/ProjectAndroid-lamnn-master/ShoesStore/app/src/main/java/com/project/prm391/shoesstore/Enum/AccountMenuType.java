package com.project.prm391.shoesstore.Enum;


public enum AccountMenuType {

    PERSONAL_INFO,
    ORDER_LIST,
    FAVORITE_PRODUCTS,
    SHOP_INFO,
    LOGOUT

}
