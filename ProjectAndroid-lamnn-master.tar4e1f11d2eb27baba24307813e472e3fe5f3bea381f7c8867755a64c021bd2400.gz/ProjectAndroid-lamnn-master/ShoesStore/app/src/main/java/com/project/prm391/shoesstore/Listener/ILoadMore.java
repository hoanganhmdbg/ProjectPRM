package com.project.prm391.shoesstore.Listener;

/**
 * Created by Lenovo S410p on 8/5/2016.
 */
public interface ILoadMore {
    void LoadMore(int totalItem);
}
