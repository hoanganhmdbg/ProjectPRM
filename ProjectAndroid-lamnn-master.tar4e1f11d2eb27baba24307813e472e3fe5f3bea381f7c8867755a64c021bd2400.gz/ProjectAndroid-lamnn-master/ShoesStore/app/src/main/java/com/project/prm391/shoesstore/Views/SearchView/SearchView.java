package com.project.prm391.shoesstore.Views.SearchView;

/**
 * Created by lamtu on 2018-03-07.
 */

public interface SearchView {

}
