package com.project.prm391.shoesstore.Entity;

public enum PaymentMethod {
    CASH_ON_DELIVERY,
    BANK_TRANSFER
}
