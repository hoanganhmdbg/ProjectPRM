package com.project.prm391.shoesstore.Views.CategoriesView;

import java.util.List;
import java.util.Map;

/**
 * Created by duytoquang on 3/21/18.
 */

public interface CategoriesView {

    void loadDataToListView(List headers, Map<Object, List> children);

}
