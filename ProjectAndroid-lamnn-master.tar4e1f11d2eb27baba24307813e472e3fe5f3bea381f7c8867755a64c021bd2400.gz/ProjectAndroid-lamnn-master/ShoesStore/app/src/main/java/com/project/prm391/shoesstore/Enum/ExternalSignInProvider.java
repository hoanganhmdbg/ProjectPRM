package com.project.prm391.shoesstore.Enum;

/**
 * Created by nguyen on 3/22/2018.
 */

public enum ExternalSignInProvider {
    GOOGLE,
    FACEBOOK
}
